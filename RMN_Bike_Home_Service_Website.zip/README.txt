RMN Bike Home Service — free website starter

Files:
- index.html: complete responsive website with booking form and WhatsApp handoff.

How bookings work:
1. Customer fills the form.
2. The website opens WhatsApp with the booking details prefilled.
3. Customer must press Send in WhatsApp.
4. You contact the customer to confirm availability and charges.

To publish free:
1. Create an account at GitHub (github.com).
2. Create a new public repository named rmn-bike-home-service.
3. Upload index.html to the repository root.
4. Open repository Settings -> Pages.
5. Under Build and deployment, select Deploy from a branch, branch main, folder /(root), then Save.
6. Wait for the Pages URL to appear; it will look like https://YOUR-USERNAME.github.io/rmn-bike-home-service/
No custom domain is required.

Important:
- This is a static website. It does not store bookings in a database or send automatic notifications by itself.
- Customers must press Send in WhatsApp after the message opens.
- Test the booking form on your phone before sharing the site.
